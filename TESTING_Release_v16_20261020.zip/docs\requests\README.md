# Αιτήματα προς τρίτους — Ευρετήριο, Προθεσμίες & Αποδεικτικά

> Οι ημερομηνίες είναι **προτεινόμενες (προς επιβεβαίωση)**· D0 = ημερομηνία αποστολής.

| # | Αίτημα | Αποδέκτης | Προθεσμία | Αποδεικτικό που κλείνει |
|---|---|---|---|---|
| E1 | `PO_REQUEST.md` (+ `PO_MESSAGE.md`) | Product Owner | **D+2** | Υπογεγραμμένη λίστα consumers **ή** ρητή «δεν υπάρχουν» |
| E2b | `DEVOPS_REQUEST.md` + `tools/analyze-phase0-logs.ps1` | DevOps | **D+14** (14ήμερο) | `phase0_summary.csv`, `phase0_by_endpoint.csv`, `phase0_report.md` |
| E3 | `GITHUB_CI_REQUEST.md` + `tools/verify-ci-artifacts.ps1` | Υπεύθυνος GitHub | **D+3** | Run URL + commit SHA + artifacts + verifier PASS |
| E4–E6 | `DBA_REQUEST.md` | DBA | **D+3** | 11 αποδεικτικά (βλ. πίνακα DBA_REQUEST §2) |
| E7–E9 | `../GO_LIVE_PLAN.md` | SEC + PO + DEV | μετά E1–E6 | Υπογεγραμμένη έγκριση + logs 400/403 |

## Checklist ανά αίτημα
### PO
- [ ] Απάντηση σε 6 ερωτήσεις
- [ ] Λίστα ή ρητή δήλωση
- [ ] Ονοματεπώνυμο/ρόλος/ημερομηνία/υπογραφή

### DevOps
- [ ] Επιβεβαίωση έκδοσης (commit/tag) που παράγει Phase 0 logs
- [ ] 14 συνεχόμενες ημέρες logs
- [ ] Εκτέλεση analyzer → 3 αρχεία
- [ ] Δήλωση πληρότητας (πρώτο/τελευταίο timestamp)

### GitHub
- [ ] Repo + push του τρέχοντος commit
- [ ] Workflow run (build-and-test, playwright-tests, security-scan, docker-build)
- [ ] Λήψη artifacts + `verify-ci-artifacts.ps1 -ExpectedCommitSha <sha> -Strict` → PASS

### DBA
- [ ] `.bak` + SHA256 + `VERIFYONLY` valid
- [ ] FILELISTONLY + rehearsal restore
- [ ] Μετρητές/fingerprints + `DBCC CHECKDB` 0 errors
- [ ] Restore-based rollback rehearsal
- [ ] Χρόνοι/χώρος/αποκλίσεις
