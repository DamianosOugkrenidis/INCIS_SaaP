# CSRF — Τελική Αξιολόγηση

Ημερομηνία: 2026-10-20 · Σχετικό εύρημα: R2 (`RISK_REGISTER.md`).

## 1. Δεδομένα συστήματος
- Αυθεντικοποίηση: **cookie** (ASP.NET Identity)· **δεν** υπάρχει ενεργό JWT bearer.
- Cookie: **SameSite=Lax** (`Program.cs:461`), `LoginPath=/Account/Login`, `AccessDeniedPath=/Account/AccessDenied`.
- API write endpoints (`ApiExtendedController`): **χωρίς** `[ValidateAntiForgeryToken]` (API-style).
- MVC POST actions (π.χ. Import): **με** `[ValidateAntiForgeryToken]`.
- CSP ορίζεται (`Program.cs:859-861`).

## 2. Τι καλύπτει και τι ΟΧΙ το SameSite=Lax
| Σενάριο | Αποτέλεσμα |
|---|---|
| Cross-site `<form method=POST>` προς `/api/v1/*` | **Μπλοκάρεται** (το Lax δεν στέλνει cookie σε cross-site POST) |
| Cross-site fetch/XHR με credentials | **Μπλοκάρεται** (no cookie) |
| Top-level cross-site **GET** πλοήγηση | Στέλνεται cookie (ασφαλές για idempotent GETs) |
| **Same-site** (subdomain) κακόβουλη σελίδα | **Δεν μπλοκάρεται** (Lax ≠ Strict) |
| **XSS** στο ίδιο origin | **Δεν μπλοκάρεται** (τα CSRF tokens επίσης δεν προστατεύουν από XSS) |
| Παλαιότεροι browsers χωρίς SameSite | Εξαρτάται από defaults |

**Συμπέρασμα:** το `SameSite=Lax` είναι **σημαντικός μετριασμός**, **όχι πλήρης απόδειξη προστασίας** για όλες τις διαδρομές/σενάρια.

## 3. Εκτίμηση κινδύνου
- **Πιθανότητα:** Χαμηλή (απαιτεί same-site/XSS ή bypass SameSite).
- **Επίδραση:** Μέτρια–Υψηλή (state-changing API writes: clients/suppliers/incis/rawmaterials/restrictions/formulas).
- **Τρέχουσα κατάσταση:** **OPEN (Medium)** — τεκμηριωμένο, δεν αποκρύπτεται.

## 4. Απαιτούμενη αντιμετώπιση (πριν/μετά το H-2)
1. **Επιβεβαίωση cookie flags:** `HttpOnly`, `Secure` (σε HTTPS), `SameSite=Lax` — ελέγχεται στο deployment.
2. **Επιλογή μηχανισμού για API writes:**
   - (α) antiforgery token (double-submit) για cookie-based API, **ή**
   - (β) μετάβαση API auth σε **bearer/JWT** (τότε CSRF δεν εφαρμόζεται, αλλά απαιτείται θωράκιση token).
3. **CSP/XSS:** διατήρηση CSP· έλεγχος output encoding (XSS προϋπόθεση για same-origin CSRF).
4. **Τεκμηρίωση αποδοχής κινδύνου** αν επιλεγεί προσωρινή παραμονή σε Lax-only, με χρονικό όριο.

## 5. Tests/αποδεικτικά
- `ApiWriteStatusCodesTests.ApiWrites_DoNotUseAntiforgeryToken_MvcImportDoes` — επιβεβαιώνει ότι τα API writes είναι χωρίς antiforgery και τα MVC Import με.
- `ApiWriteStatusCodesTests.Anonymous_ApiWrite_Returns401` — ανώνυμος αποκλείεται.
- Cookie ρύθμιση: `Program.cs:461` (SameSite=Lax).

> Το CSRF **δεν** θεωρείται «κλειστό» μόνο λόγω SameSite· απαιτείται ρητή απόφαση §4 πριν το GO.
