using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.Extensions.DependencyInjection;
using INCIS_SaaP.Models;
using Xunit;

namespace INCIS_SaaP.Tests.Integration;

/// <summary>
/// Επαληθεύει ότι το migration-DOWN είναι πλέον ΑΣΦΑΛΕΣ (μη-καταστροφικό) ακόμη και με
/// δεδομένα Name > 200 χαρ. (boundary 200 / 201 / 500 / 1903), χωρίς SQL error 2628 και
/// χωρίς απώλεια/περικοπή των αποθηκευμένων ονομάτων.
/// </summary>
[Trait("Category", "SqlIntegration")]
public class MigrationRollbackTests : IClassFixture<SqlServerFixture>
{
    private const string PreviousMigration = "20260702214036_AddFormulaApprovalWorkflow";

    private readonly SqlServerFixture _fx;

    public MigrationRollbackTests(SqlServerFixture fx) => _fx = fx;

    [Fact]
    public async Task Down_And_Up_Succeeds_With_Names_Over_200_Without_Truncation()
    {
        if (!_fx.Available) return;

        await using var ctx = _fx.CreateContext();
        await SqlServerFixture.ResetAsync(ctx);

        var names = new[]
        {
            new string('A', 200),   // boundary (χωράει στο παλιό όριο)
            new string('B', 201),   // οριακά πάνω από 200
            new string('C', 500)    // μέγιστο τρέχον (Name nvarchar(500))
        };

        // Το πλήρες (1903 χαρ.) ζει στο FullName (nvarchar(max)) — δεν επηρεάζει το Name.
        var longFullName = new string('D', 1903) + "TAIL";

        ctx.INCIs.Add(new INCI { Name = names[0], FullName = names[0], IsActive = true });
        ctx.INCIs.Add(new INCI { Name = names[1], FullName = names[1], IsActive = true });
        ctx.INCIs.Add(new INCI { Name = names[2], FullName = longFullName, IsActive = true });
        await ctx.SaveChangesAsync();

        var migrator = ctx.GetInfrastructure().GetRequiredService<IMigrator>();

        // ---- DOWN στη προηγούμενη migration (πρέπει να πετύχει χωρίς 2628) ----
        await migrator.MigrateAsync(PreviousMigration);

        var afterDown = await ctx.Database
            .SqlQueryRaw<string>("SELECT CONCAT(COUNT(*), '|', MAX(LEN(Name))) AS Value FROM INCIs")
            .SingleAsync();
        afterDown.Should().Be("3|500", "όλα τα ονόματα διατηρούνται χωρίς truncation");

        var migrationsAfterDown = (await ctx.Database.GetAppliedMigrationsAsync()).Count();
        migrationsAfterDown.Should().Be(13);

        // ---- UP ξανά στην τελευταία ----
        await migrator.MigrateAsync();

        var afterUp = await ctx.Database
            .SqlQueryRaw<string>("SELECT CONCAT(COUNT(*), '|', MAX(LEN(Name))) AS Value FROM INCIs")
            .SingleAsync();
        afterUp.Should().Be("3|500");

        var migrationsAfterUp = (await ctx.Database.GetAppliedMigrationsAsync()).Count();
        migrationsAfterUp.Should().Be(16);
    }
}
