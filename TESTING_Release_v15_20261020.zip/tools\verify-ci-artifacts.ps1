# verify-ci-artifacts.ps1 - verify official CI artifacts (ASCII-only for PS 5.1)
# Usage: .\verify-ci-artifacts.ps1 -ResultsDir .\downloaded-artifacts -MinCoverage 70
# Checks TRX (total/passed/failed/notExecuted) and cobertura line-rate >= MinCoverage.
# Exit code: 0 = PASS, 1 = FAIL, 2 = missing artifacts.
param(
    [Parameter(Mandatory = $true)][string]$ResultsDir,
    [double]$MinCoverage = 70.0
)

$ErrorActionPreference = "Stop"
if (-not (Test-Path -LiteralPath $ResultsDir)) { Write-Output "ResultsDir not found: $ResultsDir"; exit 2 }

$trx = @(Get-ChildItem -LiteralPath $ResultsDir -Recurse -Filter '*.trx' -ErrorAction SilentlyContinue)
# Dedupe identical TRX (same job copied twice) by SHA256.
$trx = @($trx | Group-Object { (Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash } | ForEach-Object { $_.Group[0] })
$cov = Get-ChildItem -LiteralPath $ResultsDir -Recurse -Filter 'ci-coverage.cobertura.xml' -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $cov) { $cov = Get-ChildItem -LiteralPath $ResultsDir -Recurse -Filter 'coverage.cobertura.xml' -ErrorAction SilentlyContinue | Select-Object -First 1 }
if ($trx.Count -eq 0 -or -not $cov) {
    Write-Output "MISSING_ARTIFACTS trx=$($trx.Count) coverage=$([bool]$cov)"
    exit 2
}

$total = 0; $passed = 0; $failed = 0; $notExecuted = 0
foreach ($f in $trx) {
    [xml]$x = Get-Content -LiteralPath $f.FullName -Raw
    $c = $x.TestRun.ResultSummary.Counters
    $total += [int]$c.total
    $passed += [int]$c.passed
    $failed += [int]$c.failed
    $notExecuted += @($x.TestRun.Results.UnitTestResult | Where-Object { $_.outcome -eq 'NotExecuted' }).Count
}

[xml]$cx = Get-Content -LiteralPath $cov.FullName -Raw
$line = [double]$cx.coverage.'line-rate' * 100
$branch = [double]$cx.coverage.'branch-rate' * 100

Write-Output ("TRX files={0} total={1} passed={2} failed={3} notExecuted={4}" -f $trx.Count, $total, $passed, $failed, $notExecuted)
Write-Output ("Coverage file: {0}" -f $cov.Name)
Write-Output ("Coverage line={0:N2}% branch={1:N2}% (min {2:N1}%)" -f $line, $branch, $MinCoverage)

$ok = ($failed -eq 0) -and ($total -gt 0) -and ($line -ge $MinCoverage)
if (-not $ok) {
    if ($failed -gt 0) { Write-Output "FAIL: failed tests = $failed" }
    if ($line -lt $MinCoverage) { Write-Output ("FAIL: coverage {0:N2}% < {1:N1}%" -f $line, $MinCoverage) }
    if ($total -eq 0) { Write-Output "FAIL: no tests counted" }
    exit 1
}
Write-Output "PASS: artifacts valid (0 failed, coverage >= min)"
exit 0
