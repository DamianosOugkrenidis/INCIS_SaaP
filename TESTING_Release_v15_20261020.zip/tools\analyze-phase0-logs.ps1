# analyze-phase0-logs.ps1 - H-2/CSRF Phase 0 log analysis (ASCII-only for PS 5.1)
# Usage (DevOps):
#   .\analyze-phase0-logs.ps1 -LogPath .\logs -SinceDays 14 -OutDir .\phase0-report
# Produces: phase0_summary.csv, phase0_by_endpoint.csv, phase0_report.md
# Security: masks emails (local part); never exports tokens/passwords/request bodies.
param(
    [Parameter(Mandatory = $true)][string]$LogPath,
    [int]$SinceDays = 14,
    [string]$OutDir = ".\phase0-report",
    [string[]]$KnownInternalUsers = @(),
    [switch]$NoMaskEmails
)

$ErrorActionPreference = "Stop"
$cutoff = (Get-Date).AddDays(-$SinceDays)

function Mask-Identity([string]$v) {
    if ([string]::IsNullOrWhiteSpace($v)) { return "-" }
    if ($NoMaskEmails) { return $v }
    if ($v -match '^([^@])[^@]*(@.*)$') { return $Matches[1] + '***' + $Matches[2] }
    return $v
}

$files = if (Test-Path -LiteralPath $LogPath -PathType Container) {
    Get-ChildItem -LiteralPath $LogPath -File -Filter 'incis-*.log'
} else {
    Get-Item -LiteralPath $LogPath
}
$files = @($files | Where-Object { $_.LastWriteTime -ge $cutoff })
if ($files.Count -eq 0) {
    New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
    "NO_LOG_FILES: no logs found in $LogPath for the last $SinceDays days." |
        Set-Content -LiteralPath (Join-Path $OutDir 'phase0_report.md') -Encoding UTF8
    Write-Output "NO_LOG_FILES (0)"
    exit 2
}

$policyRx = [regex]'API-write (?<dec>ALLOW|DENY \(enforced\)|PHASE-0 OBSERVATION \(no enforcement\)) (?<method>GET|POST|PUT|PATCH|DELETE) (?<path>/\S+) user=(?<user>\S+) id=(?<id>\S+)(?: matchedRole=(?<role>\S+))?(?: requiredRoles=(?<roles>[^\s]+))?'
$csrfRx   = [regex]'API-CSRF (?<dec>ALLOW|DENY \(enforced\)|PHASE-0 OBSERVATION \(no enforcement\)) (?<method>GET|POST|PUT|PATCH|DELETE) (?<path>/\S+) user=(?<user>\S+) id=(?<id>\S+) header=(?<header>\S+)'
$tsRx     = [regex]'^(?<ts>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3})'

$rows = New-Object System.Collections.Generic.List[object]
$total = 0
foreach ($f in $files) {
    $currentTs = ''
    foreach ($line in (Get-Content -LiteralPath $f.FullName)) {
        if ($tsRx.IsMatch($line)) { $currentTs = $tsRx.Match($line).Groups['ts'].Value }
        if ($line -notmatch 'API-(write|CSRF) ') { continue }
        $total++
        $ts = if ($tsRx.IsMatch($line)) { $tsRx.Match($line).Groups['ts'].Value } else { $currentTs }

        $m = $policyRx.Match($line); $cat = 'WRITE-POLICY'
        if (-not $m.Success) { $m = $csrfRx.Match($line); $cat = 'CSRF' }
        if (-not $m.Success) { continue }

        $user = $m.Groups['user'].Value
        $clientCat = if ($KnownInternalUsers -contains $user) { 'internal' } else { 'external-or-unknown' }

        $rows.Add([pscustomobject]@{
            Timestamp = $ts
            Category  = $cat
            Decision  = $m.Groups['dec'].Value
            Method    = $m.Groups['method'].Value
            Path      = $m.Groups['path'].Value
            User      = (Mask-Identity $user)
            UserId    = $m.Groups['id'].Value
            Role      = $m.Groups['role'].Value
            Required  = $m.Groups['roles'].Value
            Header    = $m.Groups['header'].Value
            ClientCat = $clientCat
        })
    }
}

New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
$rows | Export-Csv -LiteralPath (Join-Path $OutDir 'phase0_summary.csv') -NoTypeInformation -Encoding UTF8

$byEndpoint = $rows | Group-Object Category, Method, Path, Decision |
    ForEach-Object {
        $p = $_.Name -split ', '
        [pscustomobject]@{
            Category = $p[0]; Method = $p[1]; Path = $p[2]; Decision = $p[3]; Count = $_.Count
        }
    } | Sort-Object Category, Method, Path, Decision
$byEndpoint | Export-Csv -LiteralPath (Join-Path $OutDir 'phase0_by_endpoint.csv') -NoTypeInformation -Encoding UTF8

$obs = @($rows | Where-Object { $_.Decision -like 'PHASE-0*' })
$den = @($rows | Where-Object { $_.Decision -like 'DENY*' })
$allow = @($rows | Where-Object { $_.Decision -eq 'ALLOW' })
$ts = @($rows | Where-Object { $_.Timestamp } | ForEach-Object { $_.Timestamp } | Sort-Object)
$window = if ($ts.Count) { "$($ts[0]) -> $($ts[-1])" } else { "(no parseable timestamps)" }

$md = @(
    "# Phase 0 Log Analysis Report",
    "",
    "Window: last $SinceDays days (cutoff $($cutoff.ToString('s')))",
    "Log window (parsed timestamps): $window",
    "Files: $($files.Count) - API-write/CSRF lines: $total",
    "",
    "## Summary",
    "| Category | Count |",
    "|---|---|",
    "| ALLOW (authorized) | $($allow.Count) |",
    "| PHASE-0 OBSERVATION (would be denied) | $($obs.Count) |",
    "| DENY (enforced) | $($den.Count) |",
    "",
    "## By endpoint / method / decision",
    "| Category | Method | Path | Decision | Count |",
    "|---|---|---|---|---|"
)
foreach ($r in $byEndpoint) { $md += "| $($r.Category) | $($r.Method) | $($r.Path) | $($r.Decision) | $($r.Count) |" }
$md += @(
    "",
    "## Decision criteria",
    "- Cleared for H-2/CSRF Phase 1: ZERO PHASE-0 OBSERVATION from roles outside Admin/SuperUser for the full 14-day window AND written confirmation from the PO.",
    "- Any OBSERVATION => identify client/role before enabling.",
    "- ABSENCE of calls does NOT prove absence of external consumers.",
    "",
    "## Privacy",
    "- Emails masked (local part) unless -NoMaskEmails was supplied.",
    "- No tokens/passwords/request bodies are exported."
)
$md | Set-Content -LiteralPath (Join-Path $OutDir 'phase0_report.md') -Encoding UTF8

Write-Output ("OK rows={0} allow={1} observation={2} deny={3} out={4}" -f $rows.Count, $allow.Count, $obs.Count, $den.Count, $OutDir)
exit 0
