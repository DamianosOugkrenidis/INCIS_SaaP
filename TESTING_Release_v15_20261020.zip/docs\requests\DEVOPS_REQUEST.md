# Αίτημα προς DevOps — Phase 0 Log Analysis (E2b, 14 ημέρες)

**Σκοπός:** συλλογή/ανάλυση logs ώστε να αποφασιστεί αν μπορεί να ενεργοποιηθεί το H-2/CSRF enforcement.

## 1. Προϋπόθεση
Η εφαρμογή τρέχει με `Api:WritePolicy:Enforce=false` και `Api:Csrf:Enforce=false` (Phase 0). Τα logs γράφονται από:
- `ApiWritePolicyFilter`: `API-write PHASE-0 OBSERVATION ...` / `API-write ALLOW ...`
- `ApiCsrfFilter`: `API-CSRF PHASE-0 OBSERVATION ...`
- Serilog file sink: `logs/incis-*.log` (rolling ημερήσιο, retention 30).

## 2. Ενέργειες
1. **Επιβεβαιώστε** ότι η παραγωγή τρέχει την έκδοση που περιέχει τα δύο filters (commit/tag).
2. **Διατηρήστε** τα logs για **≥14 συνεχόμενες ημέρες**.
3. Εκτελέστε το εργαλείο (αντίγραφο στο `tools/`):
```powershell
.\tools\analyze-phase0-logs.ps1 -LogPath <logs_dir> -SinceDays 14 -OutDir .\phase0-report
```
4. Επιστρέψτε τα: `phase0-report\phase0_summary.csv`, `phase0_by_endpoint.csv`, `phase0_report.md`.

## 3. Ασφάλεια/ιδιωτικότητα
- Το εργαλείο **μασκάρει** emails (local-part) και **δεν** εξάγει tokens/passwords/σώματα.
- Περιορίστε την πρόσβαση στα logs/ reports σε εξουσιοδοτημένους.
- Μην επισυνάπτετε raw logs εκτός εγκεκριμένου καναλιού.

## 4. Κριτήρια απόφασης (στο report)
- **Cleared:** 0 `PHASE-0 OBSERVATION` από ρόλους εκτός Admin/SuperUser για όλο το 14ήμερο **και** written PO confirmation.
- **Not cleared:** οποιαδήποτε OBSERVATION → ταυτοποίηση client/ρόλου πριν το enforce.
- Αν το log window **δεν καλύπτει** 14 ημέρες → **παράταση** (δεν συμπεραίνεται έγκριση).
- **Η απουσία κλήσεων δεν αποδεικνύει απουσία consumers.**

## 5. Αποδεικτικό που κλείνει το E2b
Τα 3 αρχεία του report + σύντομη δήλωση κάλυψης 14 ημερών (ημερομηνίες πρώτου/τελευταίου log).
