# Αίτημα προς PO — Επιβεβαίωση Εξωτερικών API Consumers (E1)

**Από:** Release/Engineering · **Προς:** Product Owner INCIS · **Απαιτείται:** γραπτή απάντηση + υπογραφή.

## Σκοπός
Πριν ενεργοποιηθεί `Api:WritePolicy:Enforce` / `Api:Csrf:Enforce` στην παραγωγή, χρειαζόμαστε επιβεβαίωση για τυχόν εξωτερικά συστήματα που καλούν τα API write endpoints.

## Τι έχουμε ήδη εξακριβώσει από τον κώδικα (όχι από το περιβάλλον)
- **Δεν** εντοπίστηκε κανένας in-repo consumer των `/api/v1/*` writes.
- Outbound: μόνο SMTP email + webhooks προς URL που ορίζει ο χρήστης.
- Auth API: **cookie** (Identity)· bearer/JWT **δεν** είναι ενεργό.
- Άρα: **δεν μπορούμε να αποκλείσουμε** εξωτερικούς consumers → απαιτείται η δική σας επιβεβαίωση.

## Ερωτήσεις (απαντήστε Ναι / Όχι / Άγνωστο + στοιχεία)
1. Υπάρχουν εξωτερικές εφαρμογές/scripts/RPA/ETL που κάνουν **POST/PUT/DELETE** σε `/api/v1/clients|suppliers|incis|rawmaterials|restrictions|formulas`?
2. Ποιοι clients χρησιμοποιούν **cookie session** και ποιοι θα μπορούσαν να στείλουν `X-CSRF-TOKEN`?
3. Υπάρχει API gateway/proxy/WAF με καταγραφές κλήσεων?
4. Υπάρχουν προγραμματισμένες εργασίες (Task Scheduler/cron/Power Automate/Azure Functions)?
5. Υπάρχουν webhook subscribers ή άλλες outbound ροές?
6. Υπάρχει συμβατική/SLA χρήση API (ονόματα integrations, υπεύθυνοι)?

## Δήλωση (συμπληρώστε ένα)
- [ ] **Δεν υπάρχουν** εξωτερικοί API consumers.
- [ ] **Υπάρχουν** — επισυνάπτεται λίστα: όνομα, ιδιοκτήτης, endpoints, μέθοδοι, auth, συχνότητα.

**Ονοματεπώνυμο / Ρόλος:** ____________________  **Ημερομηνία:** __________
**Υπογραφή:** ____________________

## Αποδεικτικό που κλείνει το E1
Το παραπάνω συμπληρωμένο + (αν υπάρχουν) λίστα consumers. Χωρίς αυτό, τα H-2/CSRF παραμένουν **disabled** στην παραγωγή.
